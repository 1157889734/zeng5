cd /root
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/tslib/lib
export TSLIB_TSDEVICE=/dev/event0
export TSLIB_CALIBFILE=/etc/pointercal
export TSLIB_CONFFILE=/opt/tslib/etc/ts.conf
export TSLIB_PLUGINDIR=/opt/tslib/lib/ts
export TSLIB_CONSOLEDEVICE=none
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_TSEVENTTYPE=INPUT
export QT_QWS_FONTDIR=/root/fonts/
export QWS_MOUSE_PROTO=-:/dev/event0
export QWS_DISPLAY="LinuxFb:/dev/fb0:mmWidth200:mmHeight200:0"
#sh /root/del.sh
#sleep 3
#/root/drmd -qws &
#/root/hiEnvBin &
#sleep 8
#/root/main &
#sleep 3
#sh /root/process.sh &
#sh /root/taskset.sh &