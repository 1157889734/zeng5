#! /bin/bash
PROGRAM1="drmd"
PROGRAM2="main"
PROGRAM3="hiEnvBin"

sleep 2
ID=$(ps l| grep $PROGRAM1 | grep -v grep | awk '{print $3}')
echo $ID
taskset -p 0x0e $ID

sleep 1
ID=$(ps l| grep $PROGRAM2 | grep -v grep | awk '{print $3}')
echo $ID
taskset -p 0x01 $ID

sleep 1
ID=$(ps l| grep $PROGRAM3 | grep -v grep | awk '{print $3}')
echo $ID
taskset -p 0x01 $ID

sleep 60
rm -fr update.zip
rm -fr update.tar.gz
