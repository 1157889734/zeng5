killall -9 drmd 
killall -9 main
killall -9 hiEnvBin
ls /root/
