#! /bin/bash
PRO_PATH=""
#nohup ./process.sh &
PROGRAM1="drmd"
PROGRAM2="main"
PROGRAM3="hiEnvBin"

let START_FLAG=0

while true
do
    sleep 5
#----------------1111111111111111111111111------------------------------
    PRO1_NOW=`ps l| grep $PROGRAM1 | grep -v grep | wc -l`
    if [ $PRO1_NOW -lt 1 ]; then
	
		MSG=`date "+%Y-%m-%d %H:%M:%S drmd reboot"`
        echo $MSG >> ./tinfo.log
				reboot
    fi
    
    PRO1_STAT=`ps l|grep $PROGRAM1 |grep T|grep -v grep|wc -l`

    if [ $PRO1_STAT -gt 0 ] ; then
        killall -9 $PROGRAM1
        sleep 2
        MSG=`date "+%Y-%m-%d %H:%M:%S drmd st reboot"`
        echo $MSG >> ./tinfo.log
		    reboot
    fi
#----------------22222222222222222222222222222------------------------------	
    PRO2_NOW=`ps l | grep $PROGRAM2 | grep -v grep | wc -l`
    if [ $PRO2_NOW -lt 1 ]; then
        MSG=`date "+%Y-%m-%d %H:%M:%S main reboot"`
        echo $MSG >> ./tinfo.log
		    reboot
    fi
    PRO2_STAT=`ps l|grep $PROGRAM2 |grep T|grep -v grep|wc -l`
    if [ $PRO2_STAT -gt 0 ] ; then
        killall -9 $PROGRAM2
        sleep 2
		MSG=`date "+%Y-%m-%d %H:%M:%S main st reboot"`
        echo $MSG >> ./tinfo.log
		    reboot
    fi
#----------------33333333333333333333333333333------------------------------	
    PRO3_NOW=`ps l | grep $PROGRAM3 | grep -v grep | wc -l`
    if [ $PRO3_NOW -lt 1 ]; then
        MSG=`date "+%Y-%m-%d %H:%M:%S hiEnvBin reboot"`
        echo $MSG >> ./tinfo.log
		    reboot
    fi
    PRO3_STAT=`ps l|grep $PROGRAM3 |grep T|grep -v grep|wc -l`
    if [ $PRO3_STAT -gt 0 ] ; then
        killall -9 $PROGRAM3
        sleep 2
		MSG=`date "+%Y-%m-%d %H:%M:%S hiEnvBin st reboot"`
        echo $MSG >> ./tinfo.log
		    reboot
    fi
	
	
	TIME_NOW=`date "+%Y"`
    if [ $TIME_NOW -ge 2019 -a $START_FLAG -eq 0 ]; then		
		MSG=`date "+%Y-%m-%d %H:%M:%S system restart"`
		let START_FLAG=1
        echo $MSG >> ./tinfo.log
    fi
done
exit 0