#! /bin/bash

PROGRAM1=/root/update.tar.gz
Time1old=0
flag1old=0

PROGRAM2=/root/update.zip
Time2old=0
flag2old=0

PROGRAM3=/root/update.sh
Time3old=0
flag3old=0

Decho=echo
CNTNUM=1

ZERO=0
TRUE=1

while true
do
	sleep 0.5
	
	#check file PROGRAM1 Time chg
	if [ -e $PROGRAM1 ]
	then 
		Time1=$(stat -c "%Y" $PROGRAM1)
#		$Decho "Time:"$Time1

		if [ $Time1 -ne $Time1old ] && [ $Time1old -ne $ZERO ]
		then
			cnt1=$ZERO
			flag1=$TRUE
			$Decho "Time1 chg>>>>>>>>>>>"
		else
			cnt1=$(($cnt1+$TRUE))			
			if [ $cnt1 -gt $CNTNUM ]
			then
				flag1=$ZERO
				cnt1=$CNTNUM
			fi
			
#			$Decho "cnt1:" $cnt1
		fi			
		
		if [ $flag1old -eq $TRUE ]&&[ $flag1 -eq $ZERO ]
		then
			$Decho "sync1>>>>>>>>>>>"$PROGRAM1
			sync
		fi
		
		flag1old=$flag1	
		Time1old=$Time1		
	fi
	
	#check file PROGRAM2 Time chg
	if [ -e $PROGRAM2 ]
	then 
		Time2=$(stat -c "%Y" $PROGRAM2)
		$Decho "Time2:"$Time2

		if [ $Time2 -ne $Time2old ] && [ $Time2old -ne $ZERO ]
		then
			cnt2=$ZERO
			flag2=$TRUE
#			$Decho "Time2 chg>>>>>>>>>>>"
		else
			cnt2=$(($cnt2+$TRUE))			
			if [ $cnt2 -gt $CNTNUM ]
			then
				flag2=$ZERO
				cnt2=$CNTNUM
			fi
			
#			$Decho "cnt2:" $cnt2
		fi			
		
		if [ $flag2old -eq $TRUE ]&&[ $flag2 -eq $ZERO ]
		then
			$Decho "sync2>>>>>>>>>>>"$PROGRAM2
			sync
		fi
		
		flag2old=$flag2	
		Time2old=$Time2		
	fi
	
	#check file PROGRAM3 Time chg
	if [ -e $PROGRAM3 ]
	then 
		Time3=$(stat -c "%Y" $PROGRAM3)
#		$Decho "Time:"$Time3

		if [ $Time3 -ne $Time3old ] && [ $Time3old -ne $ZERO ]
		then
			cnt3=$ZERO
			flag3=$TRUE
			$Decho "Time3 chg>>>>>>>>>>>"
		else
			cnt3=$(($cnt3+$TRUE))			
			if [ $cnt3 -gt $CNTNUM ]
			then
				flag3=$ZERO
				cnt3=$CNTNUM
			fi
			
#			$Decho "cnt3:" $cnt3
		fi			
		
		if [ $flag3old -eq $TRUE ]&&[ $flag3 -eq $ZERO ]
		then
			$Decho "sync3>>>>>>>>>>>"$PROGRAM3
			sync
		fi
		
		flag3old=$flag3	
		Time3old=$Time3		
	fi
	
#	$Decho "-------------------------------------------"
done
exit 0