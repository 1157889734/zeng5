
mount -t nfs -o nolock 192.168.7.161:/home/nfs_share /mnt	
