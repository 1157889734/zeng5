#!/bin/bash
while true
do
	echo 2^2 > /dev/null
done
