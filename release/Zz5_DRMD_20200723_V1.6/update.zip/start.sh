cd /root
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/tslib/lib
export TSLIB_TSDEVICE=/dev/event0
export TSLIB_CALIBFILE=/etc/pointercal
export TSLIB_CONFFILE=/opt/tslib/etc/ts.conf
export TSLIB_PLUGINDIR=/opt/tslib/lib/ts
export TSLIB_CONSOLEDEVICE=none
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_TSEVENTTYPE=INPUT
export QT_QWS_FONTDIR=/root/fonts/
export QWS_MOUSE_PROTO=-:/dev/event0
export QWS_DISPLAY="LinuxFb:/dev/fb0:mmWidth200:mmHeight200:0"
sh /root/del.sh
sleep 5
/root/drmd -qws &
/root/hiEnvBin &
sleep 25
/root/main &

sleep 3
sh /root/process.sh &
sh /root/taskset.sh &

sleep 2
while true
do
    sleep 1
	if [ -e /root/rcS ]
	then
		mv /root/rcS /etc/init.d/rcS		
		chmod u+x /etc/init.d/rcS
		sync
		echo "cp rcS reboot"
		sleep 2
		reboot
	else			
		if [ -e /root/fastboot.bin ]
		then
			if [ -e /mnt/usb0 ]
			then	
				mv fastboot.bin /mnt/usb0/
				echo "exit finished"
				ls /mnt/usb0/
				sync
				sleep 5
				reboot
			else
				let PROGRAM1=$PROGRAM1+1		
				if [ $PROGRAM1 -gt 5 ] ; then
					echo "exit timeout"
					exit 0
				fi
			fi
		else
			echo "exit no fastboot.bin"
			exit 0
		fi
	fi
done
exit 0